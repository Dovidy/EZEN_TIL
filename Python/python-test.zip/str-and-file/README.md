# 문자열 및 파일

- [x] 세 자리 수를 곱해서 만든 가장 큰 대칭수(Palindrome)
- [x] 카이사르 암호 (Caesar Crypt) - string, num
- [x] linux grep 명령어 - find_str, file_url
- [x] wordcount
- [x] dir group
- [x] Binary to Hex (Hexadump) - file_url